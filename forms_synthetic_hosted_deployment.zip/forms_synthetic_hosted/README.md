# Hosted Google Forms Synthetic Test Bot

This is a Streamlit Community Cloud deployment bundle.

## What it does
- Inspects a multi-page Google Form.
- Preserves visible question order.
- Generates up to 100 varied fictional test records using your OpenAI API key.
- Previews and exports CSV.
- Offers a headless browser submission workflow only when the form contains a required synthetic-data marker.

## Required marker on the duplicate test form
Add a required multiple-choice question:
- Title: `Synthetic test response?`
- Option: `Yes – AI-generated test data`

The bot checks for this marker before enabling submissions. Keep synthetic data separate from genuine research responses.

## Deploy without installing Python locally
1. Create a GitHub account if you don't already have one.
2. Create a new **private** GitHub repository, e.g. `forms-synthetic-test-bot`.
3. Upload `app.py`, `requirements.txt`, and `packages.txt` to the repository root.
4. Visit https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app**, select your repository, branch `main`, and file `app.py`.
6. Deploy. Streamlit Cloud will install the listed packages.
7. Open the deployed app, paste your responder URL, and enter your OpenAI API key in the app's password field.

## Important hosting notes
- The hosted app runs Playwright headlessly on the server; it does not open a visible browser window on your Mac.
- Browser installation is attempted automatically on first use. The first inspection may take longer.
- Hosting providers can impose execution, memory, and request limits. A 100-submission run may need to be split into smaller batches and may be rate-limited by Google.
- CAPTCHA, sign-in gates, organisation restrictions, and anti-automation protections can prevent submissions. Do not try to bypass them.
- Never commit your OpenAI API key to GitHub. Enter it only in the app's password field.
- This bundle is deployment-ready; it is not already published. You must connect your own GitHub/Streamlit accounts to create the hosted URL.
